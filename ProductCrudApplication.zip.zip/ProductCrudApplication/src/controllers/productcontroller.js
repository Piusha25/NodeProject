let prodmodel=require("../models/prodmodel");
exports.saveProd=((req,res)=>{
    let{name,category,price,quantity}=req.body;
    console.log(name,category,price,quantity)
    let promise=prodmodel.saveProd(name,category,price,quantity);
    promise.then((result)=>{
        res.render("AddProduct.ejs",{msg:result});
    }).catch((err)=>{
        res.render("AddProduct.ejs",{msg:err});
    });
});
exports.home=(req,res)=>{
    res.render("home.ejs");
};
exports.addProdPage=(req,res)=>{
    res.render("AddProduct.ejs",{msg:""});
}
exports.getAllProd=(req,res)=>{
    let promise=prodmodel.getAllProd();
    promise.then((result)=>{
        res.render("viewProduct.ejs",{prodlist:result});
    });
    promise.catch((err)=>{
        res.send(err);
    });
}
exports.viewProduct=(req,res)=>{
    let p=prodmodel.getAllProd();
    p.then((r)=>{
        res.render("viewProduct.ejs",{prodlist:r});
    });
}


exports.ProFinalUpdate = (req, res) => {
    let { name,category,price,quantity,product_id } = req.body;
    
    let promise = prodmodel.finalUpdateProd(name,category,price,quantity,product_id);  // Fix name of function
    promise.then((result) => {
        console.log("save",result);
        res.render("updateProduct.ejs",{msg:result,product:{product_id,name,category,price,quantity}});
    }).catch((err) => {
       
        console.log(err);
        res.render("updateProduct.ejs",{msg:"not update",product:{product_id,name,category,price,quantity}});
    });
};

exports.uppFinal=(req,res)=>{
    let{product_id}=req.query;
    let promise=prodmodel.upfinal(product_id);
    promise.then((result)=>{
        console.log("save");
        res.render("updateProduct.ejs",{product:result[0],msg:""});
    }).catch((err)=>{
        return res.send("product not found");
    })
}
exports.delProd=(req,res)=>{
    let product_id=parseInt(req.query.product_id);
    let promise=prodmodel.delProdById(product_id);
    promise.then((result)=>{
        let p=prodmodel.getAllProd();
        p.then((result)=>{
            res.render("viewProduct.ejs",{prodlist:result});
        });
        p.catch((err)=>{
            res.send(err);
        });
        });
        promise.catch((err)=>{

        });
    
}
exports.searchUsingName=(req,res)=>{
    let{name,category}=req.query;
    let promise=prodmodel.getProdByName(name,category);
    promise.then((result)=>{
        res.json(result);
    }).catch((err)=>{
        res.send("Something went Wrong");
    });
};
exports.contact=(req,res)=>{
    res.render("contact.ejs");
}
exports.contactc=(req,res)=>{
    res.render("contact.ejs");
}