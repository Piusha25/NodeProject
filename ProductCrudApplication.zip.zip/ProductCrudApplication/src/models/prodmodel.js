
let db=require("../../db.js");

exports.saveProd=(name,category,price,quantity)=>{
    return new Promise((resolve,reject)=>{
        db.query("insert into Product values('0',?,?,?,?)",[name,category,price,quantity],(err,result)=>{
            if(err)
            {
                console.log(err);
                reject("Product Not Save");
            }
            else{
                resolve("Product Save Successfully.....")
            }
        });
    });
}
exports.getAllProd=()=>{
    return new Promise((resolve,reject)=>{
        db.query("select * from Product ",(err,result)=>{
            if(err)
            {
                reject(err);
            }
            else{
                resolve(result);
            }
        });
    });
}
exports.finalUpdateProd = (name,category,price,quantity,product_id) => {
    return new Promise((resolve, reject) => {
        db.query("UPDATE Product SET name = ?,category =?, price=?, quantity=? WHERE product_id= ?", [name,category,price,quantity,product_id], (err, result) => {
            if (err) {
                console.log(err);
                reject(err);
            } else {
                resolve("Product updated successfully");
            }
        });
    });
};


exports.upfinal=(product_id)=>{
    return new Promise((resolve,reject)=>{
        db.query("select * from product where product_id=?",[product_id],(err,result)=>{
            if(err){
                reject(err);
            }
            else{
                resolve(result);
            }
        })
    })
}
exports.delProdById=(product_id)=>{
    return new Promise((resolve,reject)=>{
        db.query("delete from product where product_id=?",[product_id],(err,result)=>{
            if(err)
            {
                reject(err);
            }
            else{
                resolve("success");
            }
        });
    });
}
exports.getProdByName=(name,category)=>{
    return new Promise((resolve,reject)=>{
        db.query("select * from product where name like'%"+name+"%' or category like '%"+category+"%'",(err,result)=>{
            if(err)
            {
                reject(err);
            }
            else{
                resolve(result);
            }
        });
    });
}