let express = require("express");
let prodctrl = require("../controllers/productcontroller");
// const { route } = require("../app");
let router = express.Router();
let app = express();
router.get("/", prodctrl.home);
router.get("/AddProduct", prodctrl.addProdPage);
router.post("/addProduct", prodctrl.saveProd);

router.get("/viewProduct", prodctrl.getAllProd);

router.post("/upddept", prodctrl.ProFinalUpdate);
router.get("/upfinal", prodctrl.uppFinal);

router.get("/delprod", prodctrl.delProd);

router.get("/searchProdByName", prodctrl.searchUsingName);
router.get("/con", prodctrl.contact);

module.exports = router;