require("dotenv").config();
let mysql=require("mysql2");
let conn=mysql.createConnection({
    host:process.env.db_host,
    user:process.env.db_user,
    password:process.env.db_password,
    database:process.env.db_dbname
});
conn.connect((err)=>{
    if(err)
    {
        console.log("database is not connected");
    }
    else{
        console.log("Database is Connected");
    }
});
module.exports=conn;